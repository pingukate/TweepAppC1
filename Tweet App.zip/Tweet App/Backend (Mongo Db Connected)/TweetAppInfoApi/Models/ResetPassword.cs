﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetAppInfoApi.Models
{
    public class ResetPassword
    {
        public string oldPassword { get; set; }
        public string newPassword { get; set; }
        public string emailId { get; set; }
    }
}
