﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace TweetAppInfoApi.Models
{
    public partial class TweetAppDbContext : DbContext
    {
        public TweetAppDbContext()
        {
        }

        public TweetAppDbContext(DbContextOptions<TweetAppDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TweetMessageInfo> TweetMessageInfos { get; set; }
        public virtual DbSet<UserInfo> UserInfos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=LAB-63751546214;Database=TweetAppDb;User ID=sa;Password=pass@word1;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<TweetMessageInfo>(entity =>
            {
                entity.HasKey(e => e.TweetId)
                    .HasName("PK_tweetMessage");

                entity.ToTable("tweetMessageInfo");

                entity.Property(e => e.TweetId).HasColumnName("tweetId");

                entity.Property(e => e.CreatedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("createdAt");

                entity.Property(e => e.TweetMessage).HasColumnName("tweetMessage");

                entity.Property(e => e.UpdatedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("updatedAt");

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TweetMessage)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__tweetMess__userI__49C3F6B7");
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK_TweetAppDb");

                entity.ToTable("userInfo");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.Property(e => e.CreatedDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDateTime");

                entity.Property(e => e.DateOfBirth)
                    .HasColumnType("date")
                    .HasColumnName("dateOfBirth");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .HasColumnName("emailId");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("first_name");

                entity.Property(e => e.Gender)
                    .HasMaxLength(10)
                    .HasColumnName("gender");

                entity.Property(e => e.LastName)
                    .HasMaxLength(10)
                    .HasColumnName("last_name");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasColumnName("password");

                entity.Property(e => e.UpdatedDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("updatedDateTime");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
