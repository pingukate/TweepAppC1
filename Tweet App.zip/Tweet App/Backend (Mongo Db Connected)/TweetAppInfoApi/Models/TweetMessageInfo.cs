﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

#nullable disable

namespace TweetAppInfoApi.Models
{
    public partial class TweetMessageInfo
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string TweetId { get; set; }
            public string? UserId { get; set; }
            public string TweetMessage { get; set; }
            public DateTime? CreatedAt { get; set; }
            public DateTime? UpdatedAt { get; set; }

            public virtual UserInfo User { get; set; }
    }
}
