﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Interface;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Repository
{
    public class DataRepository : IDataRepository
    {
        // private readonly DbContext db;
        // private readonly DbSet<TweetMessageInfo> tweetDb;
        // private readonly DbSet<UserInfo> userDb;

        private readonly IMongoCollection<UserInfo> userDb;
        private readonly IMongoCollection<TweetMessageInfo> tweetDb;
        private readonly TweetAppInfoConfig _settings;

        // public DataRepository(TweetAppDbContext tweetAppContext)
        // {
        //  db = tweetAppContext;
        //  tweetDb = db.Set<TweetMessageInfo>();
        //  userDb = db.Set<UserInfo>();
        // }
        public DataRepository(IOptions<TweetAppInfoConfig> settings)
        {
            _settings = settings.Value;
            var client = new MongoClient(_settings.TweetAppDbConnectionString);
            var database = client.GetDatabase(_settings.DataBaseName);
            userDb = database.GetCollection<UserInfo>(_settings.UserInfoCollectionName);
            tweetDb = database.GetCollection<TweetMessageInfo>(_settings.TweetMessageInfoCollectionName);
        }

        public async Task<TweetMessageInfo> CreateNewTweetInfo(TweetMessageInfo tweetInfo)
        {
            await tweetDb.InsertOneAsync(tweetInfo);
            //await db.SaveChangesAsync();
            return tweetInfo;
        }

        public async Task<UserInfo> CreateUserInfo(UserInfo user)
        {
            await userDb.InsertOneAsync(user);
            //await db.SaveChangesAsync();
            return user;
        }

        public async Task<UserInfo> EditUserInfo(UserInfo user)
        {
            await userDb.ReplaceOneAsync(c => c.UserId == user.UserId, user);
            //await db.SaveChangesAsync();
            return user;
        }

        public Task<List<TweetMessageInfo>> GetAllTweetInfo()
        {
            return tweetDb.Find(x => true).ToListAsync();
        }

        public async Task<List<TweetMessageInfo>> GetAllTweetInfoByUser(string userId)
        {
            return await tweetDb.Find<TweetMessageInfo>(x => x.UserId.Equals(userId)).ToListAsync();
        }

        public async Task<List<UserInfo>> GetAllUserInfo()
        {
            return await userDb.Find(x => true).ToListAsync();
        }

        public async Task<UserInfo> GetUserInfoByEmail(string emailId)
        {
            // return userDb.Where(x => x.EmailId == emailId).FirstOrDefault();
            return await userDb.Find<UserInfo>(c => c.EmailId == emailId).FirstOrDefaultAsync();
        }

        public async Task<UserInfo> GetUserInfoByUserId(string userId)
        {
            // return userDb.Where(x => x.UserId == userId).FirstOrDefault();
            return await userDb.Find<UserInfo>(c => c.UserId.Equals(userId)).FirstOrDefaultAsync();
        }
    }
}