﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetAppInfoApi
{
    public class TweetAppInfoConfig
    {
        public string DataBaseName { get; set; }
        public string UserInfoCollectionName { get; set; }
        public string TweetMessageInfoCollectionName { get; set; }
        public string TweetAppDbConnectionString { get; set; }
    }
}
