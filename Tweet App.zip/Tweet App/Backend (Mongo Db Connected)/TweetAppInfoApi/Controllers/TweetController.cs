﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Interface;
using TweetAppInfoApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TweetAppInfoApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TweetController : ControllerBase
    {
        private readonly ITweetInfo itweetServiceInfo;

        public TweetController(ITweetInfo _itweetServiceInfo)
        {
            itweetServiceInfo = _itweetServiceInfo;
        }

        // GET: api/<TweetController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet("{id}")]
        [Route("ViewAllTweets")]
        public async Task<IActionResult> ViewAllTweets()
        {
            try
            {
                var tweets = await itweetServiceInfo.ViewAllTweets();
                return new OkObjectResult(tweets);
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
        }

        // GET api/<TweetController>/5
        [HttpGet("{id}")]
        [Route("GetAllTweetByUserId/{UserId}")]
        public async Task<IActionResult> ViewAllTweetByUserId(string UserId)
        {
            try
            {
                var tweets = await itweetServiceInfo.ViewAllTweetsByUser(UserId);
                return new OkObjectResult(tweets);
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
        }

        // POST api/<TweetController>
        [HttpPost]
        [Route("PostTweet")]
        public async Task<IActionResult> PostTweet([FromBody] TweetMessageInfo tweetInfo)
        {
            try
            {
                var tweet = await itweetServiceInfo.PostTweet(tweetInfo);
                return new OkObjectResult(tweet);
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
        }
    }
}