﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Interface;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Services
{
    public class UserService : IUserInfo
    {
        private readonly IDataRepository sqldataRepository;

        //dependency injection
        public UserService(IDataRepository _sqldataRepository)
        {
            sqldataRepository = _sqldataRepository;
        }

        public async Task<List<UserInfo>> GetAllUsers()
        {
            try
            {
                var users = await sqldataRepository.GetAllUserInfo();
                foreach (var user in users)
                {
                    user.Password = "";
                }
                return users;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UserInfo> UserLogin(Login login)
        {
            try
            {
                if(login.emailId == "" || login.password == "")
                {
                    return null;
                } 
                else { 
                var user = await sqldataRepository.GetUserInfoByEmail(login.emailId);
                if (user == null)
                    {
                        return null;
                    }
                else if (user.Password.Trim() == login.password)
                {
                    user.Password = "";
                    return user;
                }
                return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UserInfo> UserRegistration(UserInfo userInfo)
        {
            try
            {
                var response = await sqldataRepository.GetUserInfoByEmail(userInfo.EmailId);
                if (response == null)
                {
                    var user = await sqldataRepository.CreateUserInfo(userInfo);
                    user.Password = "";
                    return user;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ResetPassword(ResetPassword resetPassword)
        {
            try
            {
                var user = await sqldataRepository.GetUserInfoByEmail(resetPassword.emailId);
                if (user.Password.Trim() == resetPassword.oldPassword)
                {
                    user.Password = resetPassword.newPassword;
                    var userUpdated = await sqldataRepository.EditUserInfo(user);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
