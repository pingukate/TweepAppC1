﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Interface;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Services
{
    public class TweetService : ITweetInfo
    {
        private readonly IDataRepository sqldataRepository;

        //dependency injection
        public TweetService(IDataRepository _sqldataRepository)
        {
            sqldataRepository = _sqldataRepository;
        }

        public async Task<TweetMessageInfo> PostTweet(TweetMessageInfo tweetInfo)
        {
            try
            {
                tweetInfo.CreatedAt = DateTime.UtcNow;
                tweetInfo.UpdatedAt = DateTime.UtcNow;
                var tweet = await sqldataRepository.CreateNewTweetInfo(tweetInfo);
                return tweet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<TweetMessageInfo>> ViewAllTweets()
        {
            try
            {
                return await sqldataRepository.GetAllTweetInfo();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<TweetMessageInfo>> ViewAllTweetsByUser(string userId)
        {
            try
            {
                return await sqldataRepository.GetAllTweetInfoByUser(userId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
