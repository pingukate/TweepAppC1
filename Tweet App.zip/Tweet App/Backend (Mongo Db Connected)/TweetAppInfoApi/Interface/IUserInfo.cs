﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Interface
{
    public interface IUserInfo
    {
        public Task<UserInfo> UserRegistration(UserInfo userInfo);
        public Task<UserInfo> UserLogin(Login login);
        public Task<bool> ResetPassword(ResetPassword resetPassword);
        public Task<List<UserInfo>> GetAllUsers();
    }
}
