﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Interface
{
    public interface IDataRepository
    {
        public Task<UserInfo> GetUserInfoByEmail(string emailId);
        public Task<UserInfo> GetUserInfoByUserId(string userId);

        public Task<List<TweetMessageInfo>> GetAllTweetInfo();
        public Task<List<TweetMessageInfo>> GetAllTweetInfoByUser(string userId);
        public Task<TweetMessageInfo> CreateNewTweetInfo(TweetMessageInfo tweetInfo);

        public Task<UserInfo> EditUserInfo(UserInfo user);
        public Task<List<UserInfo>> GetAllUserInfo();

        public Task<UserInfo> CreateUserInfo(UserInfo user);
    }
}
