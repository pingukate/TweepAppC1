export const environment = {
  production: true,
  servername: 'http://18.204.23.236:5000'
};
