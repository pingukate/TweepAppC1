import { Component, Input, OnInit } from '@angular/core';
import { LoginService } from 'src/app/service/login.service';
import { TweetMessageService } from 'src/app/service/tweet-message.service';

@Component({
  selector: 'app-view-all-tweets',
  templateUrl: './view-all-tweets.component.html',
  styleUrls: ['./view-all-tweets.component.css']
})
export class ViewAllTweetsComponent implements OnInit {



  allTweetData: any = [];
  tweetData: any[] = [];
  allTweetUsers: any[] = [];
  constructor(
    private tweetMessageService: TweetMessageService,
    private loginService: LoginService
  ) { }

  ngOnInit(): void {
    this.getAllUserDetails();
    this.getAllTweets();
  }
  onReply() {

  }
  async getAllTweets() {
    setTimeout(() => {
      let i, j
      this.tweetMessageService.viewAllTweets().subscribe(

        data => {
          if (Object.keys(data).length > 0) {
            this.allTweetData = data;

            this.allTweetData.forEach((element: any = {}) => {
              this.allTweetUsers.forEach(index => {
                if (element.userId == index.userId) {
                  element.firstName = index.firstName;
                  element.userName = element.firstName + element.userId;
                  element.postTime = element.createdAt;
                  element.tweetMsg = element.tweetMessage;
                }
              });

            });
            this.allTweetData;
          }
        });
    }, 300);
  }

  async getAllUserDetails() {
    await this.loginService.getAllUsers().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          this.allTweetUsers = data;
        }
      });
  }



  onTweetLike() {

  }

}
