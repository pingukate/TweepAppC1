﻿using Amazon.DynamoDBv2.DataModel;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

#nullable disable

namespace TweetAppInfoApi.Models
{
    [DynamoDBTable("TweetMessageInfo")]
    public partial class TweetMessageInfo
    {
        // [BsonId]
        // [BsonRepresentation(BsonType.ObjectId)]
        [DynamoDBHashKey]
        public int TweetId { get; set; }
            public int? UserId { get; set; }
            public string TweetMessage { get; set; }
            public DateTime? CreatedAt { get; set; }
            public DateTime? UpdatedAt { get; set; }
    }
}
