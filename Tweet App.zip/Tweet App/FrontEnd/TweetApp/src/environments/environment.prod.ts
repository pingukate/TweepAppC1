export const environment = {
  production: true,
  servername: 'http://localhost:50508'
};
