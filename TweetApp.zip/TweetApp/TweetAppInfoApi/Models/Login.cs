﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetAppInfoApi.Models
{
    public class Login
    {
        public string emailId { get; set; }
        public string password { get; set; }
    }
}
