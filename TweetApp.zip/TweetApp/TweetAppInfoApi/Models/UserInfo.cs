﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TweetAppInfoApi.Models
{
    public partial class UserInfo
    {
        public UserInfo()
        {
            TweetMessageInfos = new HashSet<TweetMessageInfo>();
        }

        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public virtual ICollection<TweetMessageInfo> TweetMessageInfos { get; set; }
    }
}
