﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TweetAppInfoApi.Models
{
    public partial class TweetMessageInfo
    {
        public int? UserId { get; set; }
        public int TweetId { get; set; }
        public string TweetMessage { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        public virtual UserInfo User { get; set; }
    }
}
