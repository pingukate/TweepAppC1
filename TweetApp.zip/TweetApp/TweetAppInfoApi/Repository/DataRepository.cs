﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Interface;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Repository
{
    public class DataRepository : IDataRepository
    {
        private readonly DbContext db;
        private readonly DbSet<TweetMessageInfo> tweetDb;
        private readonly DbSet<UserInfo> userDb;

        public DataRepository(TweetAppDbContext tweetAppContext)
        {
            db = tweetAppContext;
            tweetDb = db.Set<TweetMessageInfo>();
            userDb = db.Set<UserInfo>();
        }

        public async Task<TweetMessageInfo> CreateNewTweetInfo(TweetMessageInfo tweetInfo)
        {
            var TweetMessageInfo = tweetDb.Add(tweetInfo).Entity;
            await db.SaveChangesAsync();
            return TweetMessageInfo;
        }

        public async Task<UserInfo> CreateUserInfo(UserInfo user)
        {
            var userInfo = userDb.Add(user).Entity;
            await db.SaveChangesAsync();
            return userInfo;
        }

        public async Task<UserInfo> EditUserInfo(UserInfo user)
        {
            var userInfo = userDb.Update(user).Entity;
            await db.SaveChangesAsync();
            return userInfo;
        }

        public Task<List<TweetMessageInfo>> GetAllTweetInfo()
        {
            return tweetDb.ToListAsync();
        }

        public async Task<List<TweetMessageInfo>> GetAllTweetInfoByUser(int userId)
        {
            return await tweetDb.Where(x => x.UserId == userId).ToListAsync();
        }

        public async Task<List<UserInfo>> GetAllUserInfo()
        {
            return await userDb.ToListAsync();
        }

        public async Task<UserInfo> GetUserInfoByEmail(string emailId)
        {
            return userDb.Where(x => x.EmailId == emailId).FirstOrDefault();
        }

        public async Task<UserInfo> GetUserInfoByUserId(int userId)
        {
            return userDb.Where(x => x.UserId == userId).FirstOrDefault();
        }
    }
}