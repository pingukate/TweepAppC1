﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Interface;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Repository
{
    public class DataRepository : IDataRepository
    {
        private readonly IAmazonDynamoDB _amazonDynamoDB;
        private readonly IDynamoDBContext context;
        private static int id = 1;
        public DataRepository(IAmazonDynamoDB amazonDynamoDB)
        {
            _amazonDynamoDB = amazonDynamoDB;
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
        }

        static int generateId()
        {
            Random rand = new Random((int)DateTime.Now.Ticks);
            int RandomNumber;
            RandomNumber = rand.Next(1111, 99999);
            return RandomNumber;
        }

        static DateTime generateDate()
        {
            return DateTime.Now;
        }

        public async Task<TweetMessageInfo> CreateNewTweetInfo(TweetMessageInfo tweetInfo)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            TweetMessageInfo result = new TweetMessageInfo
            {
                TweetId = generateId(),
                UserId = tweetInfo.UserId,
                TweetMessage = tweetInfo.TweetMessage,
                CreatedAt = tweetInfo.CreatedAt
            };
            await context.SaveAsync(result);
            return tweetInfo;
        }

        public async Task<UserInfo> CreateUserInfo(UserInfo user)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            UserInfo result = new UserInfo
            {
                UserId = generateId(),
                FirstName = user.FirstName,
                LastName = user.LastName,
                Gender = user.Gender,
                DateOfBirth = user.DateOfBirth,
                EmailId = user.EmailId,
                Password = user.Password,
                CreatedDateTime = user.CreatedDateTime,
                UpdatedDateTime = user.UpdatedDateTime

            };
            await context.SaveAsync(result);
            return user;
        }

        public async Task<UserInfo> EditUserInfo(UserInfo user)
        {
            //    await userDb.ReplaceOneAsync(c => c.UserId == user.UserId, user);
            //await db.SaveChangesAsync();
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            await context.SaveAsync(user);
            return user;
        }

        public async Task<List<TweetMessageInfo>> GetAllTweetInfo()
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var conditions = new List<ScanCondition>();
            // you can add scan conditions, or leave empty
            return await context.ScanAsync<TweetMessageInfo>(conditions).GetRemainingAsync();
            // return tweetDb.Find(x => true).ToListAsync();
        }

        public async Task<List<TweetMessageInfo>> GetAllTweetInfoByUser(int userId)
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var search = context.ScanAsync<TweetMessageInfo>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(TweetMessageInfo.UserId),
                        ScanOperator.Equal,
                        userId
                        )
                }
                );
            var result = await search.GetRemainingAsync();
            return result;
            //return await context.LoadAsync<List<TweetMessageInfo>>(userId);
            //    return await tweetDb.Find<TweetMessageInfo>(x => x.UserId.Equals(userId)).ToListAsync();
        }

        public async Task<List<UserInfo>> GetAllUserInfo()
        {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var conditions = new List<ScanCondition>();
            // you can add scan conditions, or leave empty
            return await context.ScanAsync<UserInfo>(conditions).GetRemainingAsync();
            // return await userDb.Find(x => true).ToListAsync();
        }

         public async Task<UserInfo> GetUserInfoByEmail(string EmailId)
         {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            var search = context.ScanAsync<UserInfo>
                (
                new[]
                {
                    new ScanCondition
                    (
                        nameof(UserInfo.EmailId),
                        ScanOperator.Equal,
                        EmailId
                        )
                }
                );
            var result = await search.GetRemainingAsync();
            return result.FirstOrDefault();
        }

         public async Task<UserInfo> GetUserInfoByUserId(int userId)
         {
            DynamoDBContext context = new DynamoDBContext(_amazonDynamoDB);
            return await context.LoadAsync<UserInfo>(userId);
        }
    }
}