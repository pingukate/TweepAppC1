﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppInfoApi.Models;

namespace TweetAppInfoApi.Interface
{
    public interface ITweetInfo
    {
        public Task<List<TweetMessageInfo>> ViewAllTweets();
        public Task<List<TweetMessageInfo>> ViewAllTweetsByUser(int userId);
        public Task<TweetMessageInfo> PostTweet(TweetMessageInfo tweetInfo);
    }
}
